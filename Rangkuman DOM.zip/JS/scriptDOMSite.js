function resetSelection() {
    const boxes = document.querySelectorAll('.kotak');
    boxes.forEach(box => {
        box.style.backgroundColor = '#334155';
        box.style.borderColor = '#64748b';
        box.style.transform = 'scale(1)';
    });
    document.getElementById('selection-output').innerText = '';
}

function highlight(elements, color, message) {
    resetSelection();
    
    if (elements instanceof NodeList || elements instanceof HTMLCollection) {
        elements.forEach(el => applyStyle(el, color));
    } else if (elements) {
        applyStyle(elements, color);
    }
    
    document.getElementById('selection-output').innerText = message;
}

function applyStyle(el, color) {
    el.style.backgroundColor = color;
    el.style.borderColor = 'white';
    el.style.transform = 'scale(1.1)';
}

function demoSelectId() {
    const el = document.getElementById('kotak-1');
    highlight(el, '#2563eb', 'Element ditemukan: ID "kotak-1"');
}

function demoSelectQuery() {
    const el = document.querySelector('.special');
    highlight(el, '#16a34a', 'Element pertama dengan class ".special" ditemukan');
}

function demoSelectAll() {
    const els = document.querySelectorAll('.kotak');
    highlight(els, '#9333ea', `NodeList: ${els.length} elemen ditemukan dengan class ".kotak"`);
}


const target = document.getElementById('target-element');

function manipulateText() {
    target.querySelector('h3').innerText = "Konten Berubah!";
    target.querySelector('p').innerHTML = "Teks ini diubah menggunakan <br><code>element.innerHTML</code>";
}

function manipulateStyle() {
    target.style.backgroundColor = "#312e81";
    target.style.color = "white";
    target.style.borderRadius = "2rem";
    target.style.borderColor = "#6366f1";
    target.querySelector('p').classList.remove('text-slate-500');
    target.querySelector('p').classList.add('text-indigo-200');
}

function manipulateClass() {
    target.classList.toggle('bg-slate-800');
    target.classList.toggle('text-white');
    
    if(target.classList.contains('bg-slate-800')) {
        target.style.borderColor = '#cbd5e1';
        target.querySelector('h3').innerText = "Mode Gelap Aktif";
    } else {
        target.style.borderColor = '#e2e8f0'; 
        target.style.backgroundColor = "";
        target.style.color = "";
        target.querySelector('h3').innerText = "Target Element";
    }
}



let count = 0;
const btnCounter = document.getElementById('btn-counter');
const countDisplay = document.getElementById('count-display');

btnCounter.addEventListener('click', () => {
    count++;
    countDisplay.innerText = count;
    
    btnCounter.classList.add('ring-4', 'ring-teal-300');
    setTimeout(() => btnCounter.classList.remove('ring-4', 'ring-teal-300'), 200);
});

const inputDemo = document.getElementById('input-demo');
const inputOutput = document.getElementById('input-output');

inputDemo.addEventListener('input', (e) => {
    const val = e.target.value;
    inputOutput.innerText = val ? val : "...";
});

const hoverBox = document.getElementById('hover-box');
const hoverText = hoverBox.querySelector('span');

hoverBox.addEventListener('mouseenter', () => {
    hoverBox.className = "h-24 w-full bg-rose-500 rounded flex items-center justify-center cursor-pointer transition-colors duration-300 shadow-lg scale-105 transform";
    hoverText.innerText = "Mouse Masuk!";
    hoverText.className = "text-white font-bold text-lg";
});

hoverBox.addEventListener('mouseleave', () => {
    hoverBox.className = "h-24 w-full bg-slate-200 rounded flex items-center justify-center cursor-pointer transition-colors duration-300";
    hoverText.innerText = "Arahkan Mouse Sini";
    hoverText.className = "text-slate-500 font-medium text-sm";
});